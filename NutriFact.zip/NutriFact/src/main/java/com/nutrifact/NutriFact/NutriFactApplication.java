package com.nutrifact.NutriFact;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NutriFactApplication {

	public static void main(String[] args) {
		SpringApplication.run(NutriFactApplication.class, args);
	}

}
