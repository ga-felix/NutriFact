package com.nutrifact.NutriFact;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NutriFactApplicationTests {

	@Test
	void contextLoads() {
	}

}
